/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgif.pkgelse.örneği;

/**
 *
 * @author ozgryldz54
 */
public class İfElseÖrneği {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a=3, b=4, c=5;
        if(a==b&&b==c)
        {
            System.out.println("eşkenar ucgen");
        }
        if(a==b||b==c)
        {
            System.out.println("ikizkenar ucgen");
        }
        if(a!=b&&c!=b&&a!=c)
        {
            System.out.println("farkli ucgen");
        }
    }
    
}
