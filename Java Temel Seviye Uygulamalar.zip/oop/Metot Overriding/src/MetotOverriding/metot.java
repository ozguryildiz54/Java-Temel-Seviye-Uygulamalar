package MetotOverriding;

public class metot {
    public void mesaj()
    {
        System.out.println("Ozgur YILDIZ");
    }
}
