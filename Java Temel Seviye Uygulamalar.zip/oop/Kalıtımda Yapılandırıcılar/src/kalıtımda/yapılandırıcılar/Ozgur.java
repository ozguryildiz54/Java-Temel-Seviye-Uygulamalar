package kalıtımda.yapılandırıcılar;
public class Ozgur extends Yıldız{
    public Ozgur()
    {
        System.out.println("Ozgur YILDIZ");
    }
}
