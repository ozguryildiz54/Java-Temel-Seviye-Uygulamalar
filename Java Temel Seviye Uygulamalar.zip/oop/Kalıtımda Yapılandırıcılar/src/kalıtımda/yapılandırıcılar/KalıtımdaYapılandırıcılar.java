package kalıtımda.yapılandırıcılar;
public class KalıtımdaYapılandırıcılar {
    public KalıtımdaYapılandırıcılar()
    {
        System.out.println("Bu sınıfın varsayılan degeri");
    }
    public static void main(String[] args) {
        Ozgur nesne=new Ozgur();        
    }
    
}
