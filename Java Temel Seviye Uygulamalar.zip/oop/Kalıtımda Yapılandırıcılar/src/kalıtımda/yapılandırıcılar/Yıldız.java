package kalıtımda.yapılandırıcılar;
public class Yıldız extends KalıtımdaYapılandırıcılar{
    public Yıldız()
    {
        System.out.println("YILDIZ Ozgur");
    }
    
}
