package kompozisyon;
public class Motor {
    String araba="motor calisti, ";
    String durdu="motor durdu, ";
}
