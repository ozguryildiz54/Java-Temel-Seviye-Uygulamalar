package kompozisyon;
public class Araba {
     public static void main(String[] args) {
         Motor motor=new Motor();
         String yol="yola ciktik, ";
         String ev="eve geldik.";
        System.out.println(motor.araba+yol+motor.durdu+ev);
    }
    
}
