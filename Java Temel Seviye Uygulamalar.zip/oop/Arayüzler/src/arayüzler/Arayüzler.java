package arayüzler;
public class Arayüzler {
    public static void main(String[] args) {
        isci i=new isci();
        i.bolumYazdir();
        i.ucretBelirle(30);
    }
    
}
