package arayüzler;
public interface calisan {
    double katsayi=10;
    void bolumYazdir();
    void ucretBelirle(double ucret);
    double ucret();
    
}
